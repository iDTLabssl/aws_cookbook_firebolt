# This cookbook is no longer needed to load the aws-sdk and can be removed
# from node run_lists without any impact

Chef::Log.warn('The default aws recipe does nothing. See the readme for information on using the aws resources')
