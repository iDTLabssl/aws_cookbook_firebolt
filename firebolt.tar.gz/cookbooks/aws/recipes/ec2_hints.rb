# The ec2_hints recipe will be removed in a future version of this cookbook

Chef::Log.warn('The ec2_hint recipe is no longer necessary as Ohai detects EC2 instances automatically. If your instances are not being automatically detected please file a bug at https://github.com/chef/ohai')
