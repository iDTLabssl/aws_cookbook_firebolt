include_recipe 'idt_infra_tools'
include_recipe 'supervisor'
include_recipe 'java'